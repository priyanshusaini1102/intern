/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Priyanshu Saini
 */
public class NewClass {
     int result12,result13,result14,result21,result23,result24,result31,result32,result34,result41,result42,result43;
      
       public void result(String player1, String player2, String player3, String player4){
        char result11 = '-';
        char result22 = '-';
        char result33 = '-';
        char result44 = '-';
        
        String playerfirst = player1;
         result12 = retrn(playerfirst,player2,result12);
         result13 = retrn(playerfirst,player3,result13);
         result14 = retrn(playerfirst,player4,result14);
        
        playerfirst = player2;
         result21 = retrn(playerfirst,player1,result21);
         result23 = retrn(playerfirst,player3,result23);
         result24 = retrn(playerfirst,player4,result24);
        
        playerfirst = player3;
         result31 = retrn(playerfirst,player1,result31);
         result32 = retrn(playerfirst,player2,result32);
         result34 = retrn(playerfirst,player4,result34);
        
        playerfirst = player4;
         result41 = retrn(playerfirst,player1,result41);
         result42 = retrn(playerfirst,player2,result42);
         result43 = retrn(playerfirst,player3,result43);
        
        
        
        System.out.println("         \n            player 1  player 2   player 3   player 4 \n "
                   + "player1    "+result11+"          "+result12+"          "+result13+"          "+result14+
                  "\n player2    "+result21+"          "+result22+"          "+result23+"          "+result24+
                  "\n player3    "+result31+"          "+result32+"          "+result33+"          "+result34+
                  "\n player4    "+result41+"          "+result42+"          "+result43+"          "+result44);
    
            
        
    }
  
    public static int retrn(String plyr1,String plyr2,int results){
       
           
           if("Paper".equals(plyr1)){
            if("Stone".equals(plyr2))
                results++;
            
            else if("Paper".equals(plyr2))
                results = results;
            else 
                results-- ;
           }
            if("Stone".equals(plyr1)){
            if("Scissor".equals(plyr2))
                results++;
            
            else if("Stone".equals(plyr2))
                results = results;
            else 
                results-- ;
           }
             if("Scissor".equals(plyr1)){
            if("Paper".equals(plyr2))
                results++;
            
            else if("Scissor".equals(plyr2))
                results = results;
            else 
                results-- ;
           }
             if(results<0)
                 results = 0;
           
           return results;
        }
    
    
}
